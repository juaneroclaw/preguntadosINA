<?php $__env->startSection('content'); ?>
<div id="jugar" class="container text-center">
        <div class="row">
            <div class="col-md-12">
                <div id="quiz-wrapper">
                    <div class="border border-3 border-dark bg-white p-5 mb-5 rounded-3">
                        <h1><?php echo e($question->body); ?></h1>
                    </div>
                    <form id="pregunta" name="pregunta" method="POST" action="<?php echo e(route('respuesta')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                        <?php $__currentLoopData = $question->answer->shuffle(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if($seleccion == $answer->id): ?>
                            
                            <h3>
                                <div class="form-group">
                                    <div class="radio">
                                    <input type="radio" class="btn-check" name="options-outlined" id="<?php echo e($answer->id); ?>" autocomplete="off" value="<?php echo e($answer->id); ?>">
                                    <label class="btn btn-outline-warning <?php echo e($correcto? 'btnCorrecto':'btnincorrecto'); ?> fs-2 text-center px-5" for="<?php echo e($answer->id); ?>"><?php echo e($answer->answer); ?></label>
                                    </div>
                                </div>
                            </h3>
                            <?php else: ?>
                            <h3>
                                <div class="form-group">
                                    <div class="radio">
                                    <input type="radio" class="btn-check" name="options-outlined" id="<?php echo e($answer->id); ?>" autocomplete="off" value="<?php echo e($answer->id); ?>">
                                    <label class="btn btn-outline-warning <?php echo e($answer->is_correct? 'btnCorrecto':'btnRespuesta'); ?> fs-2 text-center px-5" for="<?php echo e($answer->id); ?>"><?php echo e($answer->answer); ?></label>
                                    </div>
                                </div>
                            </h3>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('pregunta')); ?>" id="textBtn" class="btn btn-md">Siguiente</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\juego2\preguntados\resources\views/oneQuestion/resultado.blade.php ENDPATH**/ ?>