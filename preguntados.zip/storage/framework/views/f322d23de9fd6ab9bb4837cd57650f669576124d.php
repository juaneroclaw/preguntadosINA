<?php $__env->startSection('content'); ?>
<div id="inicio" class="container">

   <div class="row pb-5">
        <div class="col-12">
        <h1 class="display-1 text-center txtInicio">Resultado Final...<?php echo e(Session::get('score')); ?></h1>
        </div>
    </div>
    <div class="row p-5">
        <div class="col-12 text-center">
            <a href="<?php echo e(route('iniciar')); ?>" id="textBtn" class="fs-3">Volver a jugar</a>
        </div>
    </div>
   </div>
        
   
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\juego2\preguntados\resources\views/oneQuestion/finalizado.blade.php ENDPATH**/ ?>